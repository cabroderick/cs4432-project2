Name: Collin Broderick
Student id: 330551505

Section I:
To compile and execute the code:
javac *.java
java App

Section II:
All sections of the program are working.

Section III:
I decided to utilize an array of String ArrayLists for my array-based index table.